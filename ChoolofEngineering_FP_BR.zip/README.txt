Choolof Engineering
Jacob Davis
Connor Dougan
Gracie Petty

jajdavis@mymail.mines.edu
crdougan@mymail.mines.edu
gpetty@mymail.mines.edu

Final Project - Beta Release
Pokalchemy

Please see AlphaReleaseNotes.txt and BetaReleaseNotes.txt for a description of what the project does, usage instructions, and bugs for those versions.